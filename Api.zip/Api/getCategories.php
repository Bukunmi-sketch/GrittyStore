<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET");
header("Content-Type: application/json");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

include '../Models/Category.php';  

$categoryInstance= new Category($conn);

$method = $_SERVER['REQUEST_METHOD'];
switch($method) {

    case 'GET':
     $stmt=$categoryInstance->getCategories();
     $categoryData=$stmt->fetchAll(PDO::FETCH_ASSOC);
     echo json_encode($categoryData);

    break;

}

?>