<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: *");
header("Access-Control-Allow-Methods: POST");
header("Content-Type: application/json; charset=UTF-8");
//header("Access-Control-Allow-Headers: Content-Type; Access-Control-Allow-Headers, Authorization, X-Requested-With");

require "../bulksmsnigeria/vendor/autoload.php";


include '../Models/Account.php';
include '../Models/Auth.php';

$orderInstance = new Order($conn);
$authInstance = new Auth($conn);

$method = $_SERVER['REQUEST_METHOD'];
switch ($method) {

        case 'POST':
                $request = json_decode(file_get_contents('php://input'));

                $userId = 2 + rand(0, time());
                $customersFirstname = $authInstance->validate($request->firstname);
                $customersLastname = $authInstance->validate($request->lastname);
                $customersEmail = $authInstance->validate($request->email);
                $customersPhone = $authInstance->validate($request->phone);
                $customersLocal = $authInstance->validate($request->lga);
                $customersState = $request->state;
                $customersAddress = $authInstance->validate($request->address);

                $referral = $authInstance->validate($request->referral);
                $paymentStatus = $request->payment_status;
                $orderStatus = $request->order_status;
                $date = date("y:m:d h:i:sa");
                $status = "unread";

                if (!empty($customersFirstname) && !empty($customersLastname) && !empty($customersEmail) && !empty($customersPhone) && !empty($customersLocal) && !empty($customersState) && !empty($customersAddress)) {
                        if (!empty($referral)) {
                                if ($authInstance->phoneNolength($customersPhone)) {
                                        if ($orderInstance->checkAgent($referral)) {
                                                if ($orderInstance->createOrder($orderId, $percentCharges, $eachPrices, $customersFirstname, $customersLastname, $customersEmail, $customersLocal, $customersAddress, $customersState, $cartitems, $customersPhone, $paymentStatus, $referral, $orderStatus, $amount, $agentcommissionfee, $status, $date)) {
                                                        $data = ["customername" => $customersFirstname, "customeremail" => $customersEmail, "orderid" => $orderId, "phone" => $customersPhone, "date" => $date];

                                                        $message = "Hello, {$customersFirstname} {$customersLastname}, you placed an order of $cartitems for #{$amount}, kindly make a payment to complete this order, you can track your order with link  https://afrimamafarms.com/pay/{$orderId}";
                                                  /*             
                                                        $client = new \GuzzleHttp\Client();

                                                        $response = $client->post(
                                                                'https://www.bulksmsnigeria.com/api/v2/sms/create',
                                                                [
                                                                        'headers' => [
                                                                                'Authorization' => 'Bearer E7ZrelytifAyEDxW6gmooCzR5Sqfod8mIjAxcwFIEF18QrRBMl9v8Ytc0mUD',
                                                                                'Content-Type' => 'application/json',
                                                                                'Accept' => 'application/json',
                                                                        ],
                                                                        'query' => [
                                                                                'to' => $customersPhone,
                                                                                'from' => 'AFRIMAMA',
                                                                                'body' => $message,
                                                                                'gateway' => '1',
                                                                                'append_sender' => '0',
                                                                        ],
                                                                ]
                                                        );
                                                        $body = $response->getBody();
                                                        //  print_r(json_decode($body));  
                                                        */
                                                $data = ["customername" => $customersFirstname, "customeremail" => $customersEmail, "orderid" => $orderId, "phone" => $customersPhone, "date" => $date, /* "message" => json_decode($body) */];
                                                } else {
                                                        $data = ["status" => 500, "message" => "failed to create order , error from afrimama server"];
                                                }
                                        } else {
                                                $data = ['status' => 500, 'message' => 'Oops! this agent does not exist'];
                                        }
                                } else {
                                        $data = ["status" => 500, "message" => "The Phone No length is not appropriate"];
                                }
                        } else {  //empty referral codes
                                if ($authInstance->phoneNolength($customersPhone)) {
                                        if ($orderInstance->createOrder($orderId, $percentCharges, $eachPrices, $customersFirstname, $customersLastname, $customersEmail, $customersLocal, $customersAddress, $customersState, $cartitems, $customersPhone, $paymentStatus, $referral, $orderStatus, $amount, $agentcommissionfee, $status, $date)) {

                                                $data = ["customername" => $customersFirstname, "customeremail" => $customersEmail, "orderid" => $orderId, "phone" => $customersPhone, "date" => $date];

                                                $message = "Hello, {$customersFirstname} {$customersLastname}, you placed an order of $cartitems for $amount, kindly make a payment to complete this order, you can track your order with this link https://afrimamafarms.com/pay/{$orderId}";
                                          /*
                                                $client = new \GuzzleHttp\Client();        

                                                $response = $client->post(
                                                        'https://www.bulksmsnigeria.com/api/v2/sms/create',
                                                        [
                                                                'headers' => [
                                                                        'Authorization' => 'Bearer E7ZrelytifAyEDxW6gmooCzR5Sqfod8mIjAxcwFIEF18QrRBMl9v8Ytc0mUD',
                                                                        'Content-Type' => 'application/json',
                                                                        'Accept' => 'application/json',
                                                                ],
                                                                'query' => [
                                                                        'to' => $customersPhone,
                                                                        'from' => 'AFRIMAMA',
                                                                        'body' => $message,
                                                                        'gateway' => '1',
                                                                        'append_sender' => '0',
                                                                ],
                                                        ]
                                                );
                                                $body = $response->getBody();
                                                //  print_r(json_decode($body));
                                                */
                                        $data = ["customername" => $customersFirstname, "customeremail" => $customersEmail, "orderid" => $orderId, "phone" => $customersPhone, "date" => $date,  /*  "message" => json_decode($body) */ ]; 
                                        } else {
                                                $data = ["status" => 500, "message" => "failed to create order , error from afrimama server"];
                                        }
                                } else {
                                        $data = ["status" => 500, "message" => "The Phone No length is not appropriate"];
                                }
                        }
                } else {
                        $data = ["status" => 500, "message" => "all fields are required to be filled"];
                }


                echo json_encode($data);
                break;
}
