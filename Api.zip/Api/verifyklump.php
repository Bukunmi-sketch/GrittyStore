<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: *");
header("Access-Control-Allow-Methods: POST");
header("Content-Type: multipart/form-data; charset=UTF-8");
//header("Content-Type: application/json; charset=UTF-8");
//header("Access-Control-Allow-Headers: Content-Type; Access-Control-Allow-Headers, Authorization, X-Requested-With");


$method = $_SERVER['REQUEST_METHOD'];
switch($method) {

    case 'POST':

     $reference=$_POST['reference'];
    
    $curl = curl_init();

    curl_setopt_array($curl, array(
    CURLOPT_URL => "https://api.useklump.com/v1/transactions/{$reference}/verify", // Pass transaction ID for validation
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_ENCODING => "",
    CURLOPT_MAXREDIRS => 10,
    CURLOPT_TIMEOUT => 0,
    CURLOPT_FOLLOWLOCATION => true,
    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
    CURLOPT_CUSTOMREQUEST => "GET",
    CURLOPT_HTTPHEADER => array(
    'Content-Type: application/json',
    'klump-secret-key: klp_sk_0680358750624fd58b33a6d33839e53306f581f8e56048f59c075162f4f11949 ', 
    ),
    ));  

    $response = curl_exec($curl);
    curl_close($curl);
    // echo  '<pre>';
    // echo $response;
    // echo '</pre>';
     echo $response;
   /// $res = json_encode($response);
   // echo [$res];

    break;
       
     

}

?>