function opennav(){
    document.querySelector(".left").style.width="100%";
    }
    function closenv(){
    document.querySelector(".left").style.width="0"; 
   // document.querySelector(".left").style.display="none"; 
    }

function myFunction() {
    document.getElementById("myDropdown").classList.toggle("show");
}

function attend(){
    document.getElementById("attendance").classList.toggle("show");
}

function campreg(){
    document.getElementById("campreg").classList.toggle("show");
}

function members(){
    document.getElementById("members").classList.toggle("show");
}

function exams(){
    document.getElementById("exams").classList.toggle("show");
}

function agents(){
    document.getElementById("agents").classList.toggle("show");
}