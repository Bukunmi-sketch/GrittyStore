<nav>
    <div class="container">
         <div class="bar" onclick="opennav()"> <i class="fa fa-navicon"></i> </div>

         <h2 class="logo">Admin Dashboard </h2>

         <div class="create">    
                <a href="dashboard.php?logout=true" class="login">Log out</a>

         </div>
    </div>
</nav>
